package paths;

import main.Particle;

public class CirclePath2D extends ParticlePath {

	double center_x;
	double center_y;
	
	@Override
	public void updatePath(Particle p) {
		
	}

}
